-- HR Analytics

use project;

-- Average Attrition rate for all Departments
select department,count("Employee ID") from hr_1
where attrition ="Yes"
group by Department;

-- Average Hourly rate of Male Research Scientist 
select JobRole, avg(HourlyRate) from hr_1
where JobRole="Research Scientist" and gender="Male";

-- Attrition rate Vs Monthly income stats 
-- (Yes)
Select department, sum(monthlyincome), avg(monthlyincome),min(monthlyincome),max(monthlyincome) from hr_1 full join  hr_2 using(EmployeeID)
Where Attrition="Yes"
group by department;
-- (No)
Select department, sum(monthlyincome), avg(monthlyincome) ,min(monthlyincome),max(monthlyincome) from hr_1 full join  hr_2 using(EmployeeID)
Where Attrition="No"
group by department;

-- Average working years for each Department
select department, avg(TotalWorkingYears) from hr_2 
full join hr_1 using(EmployeeID)
group by department;

-- Job Role Vs Work life balance  
select department,avg(WorkLifeBalance) from hr_2
 full join hr_1 using(employeeID)
group by department;

-- Attrition rate Vs Year since last promotion relation
select department,count(employeeId) from hr_1 full join hr_2 using(employeeId)
where Attrition="Yes"
group by YearsSinceLastPromotion;

